# Etch A Sketch

# Demo

[YouTube](https://www.youtube.com/watch?v=5o0ZNnvpwbM)

# Contribution
* Harsh <patel743@purdue.edu>
* Colin <unscspartan343@gmail.com>
* Rahul <rahulsaigal7@gmail.com>
* Wen-Hsiang Shih <swh@hsiang.io>

## Reference
* https://vivonomicon.com/2018/06/17/drawing-to-a-small-tft-display-the-ili9341-and-stm32/
* https://github.com/WRansohoff/STM32_ILI9341_HWSPI/blob/master/src/main.c
