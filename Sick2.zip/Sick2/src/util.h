
#include "global.h"
#include "sspi.h"

/* Utility method declarations. */
void ili9341_sspi_init(void);
void ili9341_hspi_init(void);
void delay_cycles(uint32_t cyc);
