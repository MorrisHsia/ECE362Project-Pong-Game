#include "global.h"

void draw_pad(int x, int w);
void draw_ball(int x, int y);
void update(int* x_pad, int* x_ball, int* y_ball);
