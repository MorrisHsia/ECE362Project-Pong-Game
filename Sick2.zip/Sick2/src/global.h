
#include <stdint.h>
  #include "stm32f0xx.h"

// Global variables.
uint32_t core_clock_hz;


