#include "draw.h"

void draw_pad(int x, int w){
	for(int i = 0; i < 320;++i){
			  for(int j = 0;j < 240;++j){
				  if((j < 230) & (j > 220) & (i < (x+w)) & (i > (x-w))){
					  hspi_w16(0x0000);
				  }
			  }
		  }
}

void draw_ball(int x, int y){
	for(int i = 0; i < 320;++i){
			  for(int j = 0;j < 240;++j){
				  if((j < (y + 5)) & (j > (y - 5)) & (i < (x+5)) & (i > (x-5))){
					  hspi_w16(0xFF00);
				  }
			  }
		  }
}

void update(int* x_pad, int* x_ball, int* y_ball){
	*x_pad += 1;
	*x_ball -= 1;
	*y_ball += 1;
	//placeholder for update positions
	//out of bounds

}
